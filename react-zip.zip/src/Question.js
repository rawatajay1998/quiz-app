import React from "react";
import QuestionOption from "./QuestionOption";

const Question = ({ question }) => {
  return (
    <>
      <h3>{question.question}</h3>
      <ul>
        {Object.keys(question.answers).map((key) => {
          const item = { key: key, value: question.answers[key] };

          return {};
        })}
      </ul>
    </>
  );
};

export default Question;
