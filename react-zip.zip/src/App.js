import "./App.css";
import { useEffect, useReducer, useState } from "react";
import Loading from "./Loading";
import StartScreen from "./StartScreen";
import Question from "./Question";

function App() {
  const initialState = {
    questions: [],
    status: "loading",
    index: 0,
  };

  function ReducerFunction(state, action) {
    switch (action.type) {
      case "takeQuiz":
        return { ...state, questions: action.payload, status: "ready" };
      case "start":
        return { ...state, status: "active" };
    }
  }
  const [state, dispatch] = useReducer(ReducerFunction, initialState);

  const { questions, status, index } = state;

  const numQuestions = questions.length;

  useEffect(() => {
    const getQuestions = async () => {
      const res = await fetch(
        "https://quizapi.io/api/v1/questions?apiKey=ONlotQMCq8K2TB7MkIvPhF7yQI9KtOou99W2B3C5&limit=15"
      );
      const data = await res.json();
      dispatch({ type: "takeQuiz", payload: data });
    };
    getQuestions();
  }, []);

  return (
    <div className="App">
      <main>
        <div>{status === "loading" && <Loading />}</div>
        <div>
          {status === "ready" && (
            <StartScreen dispatch={dispatch} numQuestions={numQuestions} />
          )}
        </div>
        <div>
          {status === "active" && <Question question={questions[index]} />}
        </div>
      </main>
    </div>
  );
}

export default App;
