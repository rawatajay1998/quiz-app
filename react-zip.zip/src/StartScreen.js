function StartScreen({ numQuestions, dispatch }) {
  return (
    <div>
      <h1>Welcome to the Quiz</h1>
      <p>Please pass the test of total {numQuestions} questions.</p>
      <button onClick={() => dispatch({ type: "start" })}>
        Please Start test
      </button>
    </div>
  );
}

export default StartScreen;
