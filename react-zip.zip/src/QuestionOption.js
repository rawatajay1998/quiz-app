import React from "react";

const QuestionOption = ({ options }) => {
  console.log(options);

  return (
    <>
      {options.map((option) => {
        return <button key={option}>{option}</button>;
      })}
    </>
  );
};

export default QuestionOption;
